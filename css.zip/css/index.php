<?php
echo "Error 403 Forbidden";
/* Redirect browser */
echo '<script>window.location="http://cv.lexnjugz.co.ke/"</script>';

 
/* Make sure that code below does not get executed when we redirect. */
exit;
?>